#include "ESPNowAutoPair.h"
#include <esp_wifi.h>

ESPNowAutoPair *ESPNowAutoPair::_instance = nullptr;
static const uint8_t BROADCAST_MAC[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

ESPNowAutoPair::ESPNowAutoPair()
: _tx(false), _paired(false), _rxLength(0), _newPacket(false),
  _lastReceive(0), _lastPairRequest(0), _ackCounter(0) {
  memset(_peer, 0, sizeof(_peer));
  memset(_rxBuffer, 0, sizeof(_rxBuffer));
  _instance = this; // One ESPNowAutoPair instance per MCU.
}

bool ESPNowAutoPair::beginTX() {
  _tx = true;
  _paired = false;
  _lastReceive = 0;
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  if (esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE) != ESP_OK) return false;
  if (esp_now_init() != ESP_OK) return false;
  if (esp_now_register_recv_cb(receiveCallback) != ESP_OK) return false;
  // Broadcast destination must be registered before esp_now_send().
  return addPeer(BROADCAST_MAC);
}

bool ESPNowAutoPair::beginRX() {
  _tx = false;
  _paired = false;
  _lastReceive = 0;
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  if (esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE) != ESP_OK) return false;
  if (esp_now_init() != ESP_OK) return false;
  return esp_now_register_recv_cb(receiveCallback) == ESP_OK;
}

bool ESPNowAutoPair::addPeer(const uint8_t *mac) {
  if (esp_now_is_peer_exist(mac)) return true;
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, mac, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.ifidx = WIFI_IF_STA;
  peer.encrypt = false;
  return esp_now_add_peer(&peer) == ESP_OK;
}

void ESPNowAutoPair::pairRequest() {
  const uint8_t packet[2] = {ESPNOW_MAGIC, ESPNOW_PAIR_REQUEST};
  esp_now_send(BROADCAST_MAC, packet, sizeof(packet));
}

void ESPNowAutoPair::update() {
  const uint32_t now = millis();
  if (_tx && !_paired && (uint32_t)(now - _lastPairRequest) >= 500) {
    pairRequest();
    _lastPairRequest = now;
  }
  // Receiver ACKs are sent periodically; missing ACKs cause the TX to re-pair.
  if (_tx && _paired && _lastReceive != 0 && (uint32_t)(now - _lastReceive) > 400) {
    forget();
  }
}

bool ESPNowAutoPair::paired() { return _paired; }

bool ESPNowAutoPair::send(const uint8_t *data, size_t length) {
  if (!_paired || data == nullptr || length == 0 || length > ESPNOW_MAX_DATA - 2) return false;
  uint8_t packet[ESPNOW_MAX_DATA];
  packet[0] = ESPNOW_MAGIC;
  packet[1] = ESPNOW_DATA;
  memcpy(packet + 2, data, length);
  return esp_now_send(_peer, packet, length + 2) == ESP_OK;
}

bool ESPNowAutoPair::receive(uint8_t *data, size_t maxLength, size_t &length) {
  length = 0;
  if (data == nullptr || maxLength == 0) return false;
  portENTER_CRITICAL(&_mux);
  if (!_newPacket) {
    portEXIT_CRITICAL(&_mux);
    return false;
  }
  size_t n = _rxLength;
  if (n > maxLength) n = maxLength;
  memcpy(data, _rxBuffer, n);
  _newPacket = false;
  portEXIT_CRITICAL(&_mux);
  length = n;
  return true;
}

bool ESPNowAutoPair::failsafe(uint32_t timeoutMs) {
  const uint32_t last = _lastReceive;
  return !_paired || last == 0 || (uint32_t)(millis() - last) > timeoutMs;
}

uint32_t ESPNowAutoPair::lastReceive() { return _lastReceive; }

void ESPNowAutoPair::forget() {
  if (_paired && esp_now_is_peer_exist(_peer)) esp_now_del_peer(_peer);
  memset(_peer, 0, sizeof(_peer));
  _paired = false;
  _lastReceive = 0;
  _ackCounter = 0;
  portENTER_CRITICAL(&_mux);
  _newPacket = false;
  _rxLength = 0;
  portEXIT_CRITICAL(&_mux);
}

void ESPNowAutoPair::receiveCallback(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (_instance) _instance->onReceive(info, data, len);
}

void ESPNowAutoPair::onReceive(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (!info || !data || len < 2 || data[0] != ESPNOW_MAGIC) return;

  if (!_tx && data[1] == ESPNOW_PAIR_REQUEST) {
    // Do not let a second transmitter take over an active paired receiver.
    if (_paired && memcmp(info->src_addr, _peer, 6) != 0) return;
    memcpy(_peer, info->src_addr, 6);
    if (!addPeer(_peer)) return;
    const uint8_t response[2] = {ESPNOW_MAGIC, ESPNOW_PAIR_RESPONSE};
    esp_now_send(_peer, response, sizeof(response));
    _paired = true;
    _lastReceive = millis();
    return;
  }

  if (_tx && data[1] == ESPNOW_PAIR_RESPONSE) {
    memcpy(_peer, info->src_addr, 6);
    if (!addPeer(_peer)) return;
    _paired = true;
    _lastReceive = millis();
    return;
  }

  if (_tx && _paired && data[1] == ESPNOW_LINK_ACK && memcmp(info->src_addr, _peer, 6) == 0) {
    _lastReceive = millis();
    return;
  }

  if (!_tx && _paired && data[1] == ESPNOW_DATA && memcmp(info->src_addr, _peer, 6) == 0) {
    const int n = len - 2;
    if (n <= 0 || n > ESPNOW_MAX_DATA) return;
    portENTER_CRITICAL(&_mux);
    memcpy(_rxBuffer, data + 2, n);
    _rxLength = (size_t)n;
    _newPacket = true;
    portEXIT_CRITICAL(&_mux);
    _lastReceive = millis();
    if (++_ackCounter >= 5) { // 10 Hz ACK at a 50 Hz RC packet rate.
      const uint8_t ack[2] = {ESPNOW_MAGIC, ESPNOW_LINK_ACK};
      esp_now_send(_peer, ack, sizeof(ack));
      _ackCounter = 0;
    }
  }
}
