/*
 * ESP-NOW receiver bearer for PlainFlightController.
 * Application payload: packed RcPacket { version, sequence, channel[8], crc }.
 * Incoming transmitter packet order: AETR, AUX1, AUX2, AUX3, AUX4.
 * Adapter remaps AETR to PlainFlight's internal TAER order; AUX channels stay put.
 * Channel values are uint16_t pulse widths in microseconds (1000-2000).
 */
#pragma once

#include "RxBase.hpp"
#include <Arduino.h>
#include "ESPNowAutoPair.h"

class EspNow : public RxBase
{
public:
  EspNow();

  bool getDemands() override;
  const RxPacket getData() override;
  const bool hasLostCommunications() override;

  uint32_t getChannelIndex(RcChannelName name) const override
  {
    return static_cast<uint32_t>(name);
  }

private:
  static constexpr uint32_t CHANNEL_COUNT = 8U;
  static constexpr uint32_t FAILSAFE_TIMEOUT_MS = 300U;

  struct __attribute__((packed)) RcPacket
  {
    uint8_t version;
    uint16_t sequence;
    uint16_t channel[CHANNEL_COUNT];
    uint16_t crc;
  };
  static_assert(sizeof(RcPacket) == 21U, "ESP-NOW RC packet layout must be 21 bytes");

  ESPNowAutoPair m_link;
  bool m_started = false;
  bool m_initAttempted = false;
  bool m_haveSequence = false;
  uint16_t m_lastSequence = 0U;
  uint32_t m_lastGoodPacketMs = 0U;

  static uint16_t crc16Ccitt(const uint8_t *data, size_t length);
  void setFailsafe();
};
