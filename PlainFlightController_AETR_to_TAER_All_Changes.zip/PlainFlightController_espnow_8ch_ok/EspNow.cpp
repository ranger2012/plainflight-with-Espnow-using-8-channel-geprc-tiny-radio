#include "EspNow.hpp"
#include "Utilities.hpp"
#include "InternalConfig.hpp"
#include <cstring>

EspNow::EspNow()
{
  // IMPORTANT: DemandProcessor is a FlightControl member and is constructed
  // before Arduino setup(). Do not start Wi-Fi/ESP-NOW or print to Serial here.
  // Hardware initialization is deferred until getDemands() runs in loop().
  m_rxData.failsafe = true;
  m_rxData.lostComms = true;
}

uint16_t EspNow::crc16Ccitt(const uint8_t *data, size_t length)
{
  uint16_t crc = 0xFFFFU;
  while (length--)
  {
    crc ^= static_cast<uint16_t>(*data++) << 8;
    for (uint8_t bit = 0; bit < 8U; ++bit)
    {
      crc = (crc & 0x8000U)
        ? static_cast<uint16_t>((crc << 1) ^ 0x1021U)
        : static_cast<uint16_t>(crc << 1);
    }
  }
  return crc;
}

bool EspNow::getDemands()
{
  // First call occurs from the normal Arduino loop, after Serial.begin() and
  // after the ESP32 Arduino runtime is initialized. Never call beginRX() from
  // a global/member constructor.
  if (!m_initAttempted)
  {
    m_initAttempted = true;
    Serial.println("ESP-NOW RX: initializing...");
    m_started = m_link.beginRX();
    if (!m_started)
    {
      Serial.println("ESP-NOW RX: INIT FAILED");
      setFailsafe();
      return false;
    }
    Serial.println("ESP-NOW RX READY - waiting for C3 auto-pair request");
    Serial.println("Protocol: v1 / 8 channels / sequence / CRC16 / 50 Hz");
  }

  if (!m_started)
  {
    setFailsafe();
    return false;
  }

  // Keep the auto-pair/heartbeat state machine serviced by PlainFlight's loop.
  m_link.update();

  uint8_t payload[ESPNOW_MAX_DATA] = {};
  size_t length = 0U;
  if (m_link.receive(payload, sizeof(payload), length))
  {
    if (length != sizeof(RcPacket))
    {
      setFailsafe();
      return false;
    }

    RcPacket packet{};
    memcpy(&packet, payload, sizeof(packet));

    const uint16_t expectedCrc = crc16Ccitt(
      reinterpret_cast<const uint8_t *>(&packet),
      sizeof(packet) - sizeof(packet.crc));
    const bool versionOk = packet.version == 1U;
    const bool crcOk = packet.crc == expectedCrc;

    // A transmitter reboot/link outage can restart its sequence counter at 1.
    // Once the 300 ms RC failsafe interval has elapsed, accept a fresh sequence epoch.
    const uint32_t nowMs = millis();
    if (m_lastGoodPacketMs == 0U ||
        static_cast<uint32_t>(nowMs - m_lastGoodPacketMs) >= FAILSAFE_TIMEOUT_MS)
    {
      m_haveSequence = false;
    }

    // Signed difference handles uint16_t sequence rollover within one link epoch.
    const bool sequenceOk = !m_haveSequence ||
      static_cast<int16_t>(packet.sequence - m_lastSequence) > 0;

    bool channelsOk = true;
    for (uint32_t i = 0U; i < CHANNEL_COUNT; ++i)
    {
      if (packet.channel[i] < 900U || packet.channel[i] > 2100U)
      {
        channelsOk = false;
        break;
      }
    }

    if (!versionOk || !crcOk || !sequenceOk || !channelsOk)
    {
      setFailsafe();
      return false;
    }

    // The C3 transmitter sends AETR order:
    //   packet CH1=Aileron/Roll, CH2=Elevator/Pitch,
    //   CH3=Throttle, CH4=Rudder/Yaw.
    // PlainFlight's RcChannelName indices are TAER:
    //   m_rxData.ch[0]=Throttle, [1]=Roll, [2]=Pitch, [3]=Yaw.
    // Keep the four AUX channels in their original positions.
    static constexpr uint8_t PACKET_INDEX_FOR_PLAINFO_CHANNEL[CHANNEL_COUNT] =
    {
      2U,  // PlainFlight THROTTLE <- transmitter CH3
      0U,  // PlainFlight ROLL     <- transmitter CH1
      1U,  // PlainFlight PITCH    <- transmitter CH2
      3U,  // PlainFlight YAW      <- transmitter CH4
      4U,  // AUX1 / ARM           <- transmitter CH5
      5U,  // AUX2 / MODE          <- transmitter CH6
      6U,  // AUX3                 <- transmitter CH7
      7U   // AUX4                 <- transmitter CH8
    };

    for (uint32_t i = 0U; i < CHANNEL_COUNT; ++i)
    {
      const uint32_t packetIndex = PACKET_INDEX_FOR_PLAINFO_CHANNEL[i];
      const int32_t pulseUs = constrain(static_cast<int32_t>(packet.channel[packetIndex]), 1000, 2000);
      m_rxData.ch[i] = map32(pulseUs, 1000, 2000, MIN_NORMALISED, MAX_NORMALISED);
    }

    m_lastSequence = packet.sequence;
    m_haveSequence = true;
    m_lastGoodPacketMs = millis();
    m_rxData.failsafe = false;
    m_rxData.lostComms = false;

    if constexpr (InternalConfig::DEBUG_RX)
    {
      Serial.printf("ESP-NOW RX seq=%u CH1=%u CH2=%u CH3=%u CH4=%u CH5=%u CH6=%u CH7=%u CH8=%u \n",
                    packet.sequence, packet.channel[0], packet.channel[1],
                    packet.channel[2], packet.channel[3], packet.channel[4],
                    packet.channel[5], packet.channel[6], packet.channel[7]);
    }
    return true;
  }

  if (!m_link.paired() || m_lastGoodPacketMs == 0U ||
      static_cast<uint32_t>(millis() - m_lastGoodPacketMs) >= FAILSAFE_TIMEOUT_MS)
  {
    setFailsafe();
  }
  return false;
}

void EspNow::setFailsafe()
{
  m_rxData.failsafe = true;
  m_rxData.lostComms = true;
}

const RxBase::RxPacket EspNow::getData()
{
  return m_rxData;
}

const bool EspNow::hasLostCommunications()
{
  return m_rxData.lostComms;
}
