/* 
* Copyright (c) 2025 P.Cook (alias 'plainFlight')
*
* This file is part of the PlainFlightController distribution (https://github.com/plainFlight/plainFlightController).
* 
* This program is free software: you can redistribute it and/or modify  
* it under the terms of the GNU General Public License as published by  
* the Free Software Foundation, version 3.
*
* This program is distributed in the hope that it will be useful, but 
* WITHOUT ANY WARRANTY; without even the implied warranty of 
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
* General Public License for more details.
*
* You should have received a copy of the GNU General Public License 
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/**
* @file   DemandProcessor.cpp
* @brief  This class handles RC commands and makes them into meaningful control demands.
*/

#include "DemandProcessor.hpp"
#include "InternalConfig.hpp"


/**
* @brief    DemandProcessor constructor   
*/
DemandProcessor::DemandProcessor()
{
  // Instantiation code receiver protocols
  ReceiverBearer::create(&radioCtrl, &m_telemetry);
  m_normalisedData = radioCtrl->getData();  // Copy across initial data state i.e. failsafe flag state
}


/**
* @brief    DemandProcessor destructor   
*/
DemandProcessor::~DemandProcessor()
{
  delete radioCtrl;
  radioCtrl = nullptr;
}

/**
* @brief    Processes RC data to determine operating mode and any drive demands.
* @param    flightState   Pointer to the current flight state.
* @param    lastFlightState   Pointer to the previous flight state.
* @param    modelCategory Used as multicopters must not have pass through state
*/
void
DemandProcessor::process(FlightState* const flightState,
                         FlightState* const lastFlightState,
                         FileSystem::Rates const * const rates,
                         FileSystem::MaxAngle const * const maxAngle)
{
  m_newRxPacket = radioCtrl->getDemands();

  if (m_newRxPacket)  //Rx processing
  {
    //New Rx packet received so process it
    m_normalisedData = radioCtrl->getData();
    decodeOperatingMode(flightState, lastFlightState);
    decodeStickPositions(flightState, rates, maxAngle);
  }
  else
  {
    decodeOperatingMode(flightState, lastFlightState);
  }
}


/**
* @brief    Decode transmitter stick positions into meaningful demands.
* @param    flightState   Pointer to the current flight state.
*/
void
DemandProcessor::decodeStickPositions(FlightState const* const flightState, FileSystem::Rates const* const rates, FileSystem::MaxAngle const* const maxAngle)
{
  //Normalise stick commands to signed values that we can work with
  m_demand.pitch = radioCtrl->getChannel<RcChannelName::PITCH>(m_normalisedData);

  if (Config::TX_DEADBAND_NORM > abs(m_demand.pitch))
  {
    m_demand.pitch = 0;
  }

  m_demand.roll = radioCtrl->getChannel<RcChannelName::ROLL>(m_normalisedData);

  if (Config::TX_DEADBAND_NORM > abs(m_demand.roll))
  {
    m_demand.roll = 0;
  }

  m_demand.yaw = radioCtrl->getChannel<RcChannelName::YAW>(m_normalisedData);

  if (Config::TX_DEADBAND_NORM > abs(m_demand.yaw))
  {
    m_demand.yaw = 0;
  }

  m_demand.throttle = radioCtrl->getChannel<RcChannelName::THROTTLE>(m_normalisedData);
  
  if constexpr (Config::USE_FLAPS)
  {
    m_demand.flaps = radioCtrl->getChannel<Config::FLAPS_CHANNEL>(m_normalisedData);
  }

  switch (*flightState)
  {
  case FlightState::ACRO_TRAINER:
    //Acro trainer uses degrees per sec, when levelling the angle demands are zero.
    //Intentional fall through
  case FlightState::RATE:
    //Map control inputs to degrees per second.
    m_demand.pitch = map32(m_demand.pitch, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->pitch, rates->pitch);
    m_demand.roll = map32(m_demand.roll, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->roll, rates->roll);
    m_demand.yaw = map32(m_demand.yaw, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->yaw, rates->yaw);
    break;

  case FlightState::SELF_LEVELLED:
    //Map control inputs to degrees.
    m_demand.pitch = map32(m_demand.pitch, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -maxAngle->pitch, maxAngle->pitch);
    m_demand.roll = map32(m_demand.roll, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -maxAngle->roll, maxAngle->roll);
    //Yaw still works in degrees per second.
    m_demand.yaw = map32(m_demand.yaw, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->yaw, rates->yaw);
    break;

  case FlightState::PROP_HANG:
    //Map control inputs to degrees.
    m_demand.pitch = map32(m_demand.pitch, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -maxAngle->pitch, maxAngle->pitch);
    if constexpr (Config::PROP_HANG_TAIL_SITTER_MODE)
    {
      //Roll works in rate mode
      m_demand.roll = map32(m_demand.roll, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -maxAngle->roll, maxAngle->roll);
      //Yaw set to max roll angle
      m_demand.yaw = map32(m_demand.yaw, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->roll, rates->roll);
    }
    else
    {
      //Roll works in rate mode
      m_demand.roll = map32(m_demand.roll, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -rates->roll, rates->roll);
      //Yaw set to max roll angle
      m_demand.yaw = map32(m_demand.yaw, RxBase::MIN_NORMALISED, RxBase::MAX_NORMALISED, -maxAngle->roll, maxAngle->roll);
    }
    break;

  case FlightState::FAILSAFE:
    m_demand = DEFAULT_DEMANDS;
    break;

  default:
    //Assume pass through for all other states.
    break;
  }
}


/**
* @brief  Determines what state the radio control system is in  
* @param    flightState   Pointer to the current flight state.
* @param    lastFlightState   Pointer to the previous flight state.
*/
void
DemandProcessor::decodeOperatingMode(FlightState* const flightState, FlightState* const lastFlightState)
{
  FlightState demandedFlightState = *flightState;
  m_demand.armed = RxBase::isSwitchHigh(radioCtrl->getChannel<Config::ARM_CHANNEL>(m_normalisedData));
  m_throttleHigh = (RxBase::LOW_THROTTLE_NORM < radioCtrl->getChannel<RcChannelName::THROTTLE>(m_normalisedData));
  // Check headinHold and propHang each pass to ensure state is correctly reflected when disarmed
  if constexpr(Config::USE_HEADING_HOLD)
  {
    m_demand.headingHold = RxBase::isSwitchHigh(radioCtrl->getChannel<Config::HEADING_HOLD_CHANNEL>(m_normalisedData));
  }

  if constexpr(Config::USE_PROP_HANG_MODE)
  {
    m_demand.propHang = RxBase::isSwitchHigh(radioCtrl->getChannel<Config::PROP_HANG_CHANNEL>(m_normalisedData));
  }

  if (FlightState::CALIBRATE == demandedFlightState)
  {
    ; //Let calibration complete
  }
  else if (radioCtrl->hasLostCommunications() || m_normalisedData.failsafe)
  {
    demandedFlightState = FlightState::FAILSAFE;
  }
  else if (((FlightState::FAILSAFE == *lastFlightState)
          || (FlightState::CALIBRATE == *lastFlightState) 
          || (FlightState::WAITING_TO_DISARM == *flightState))
           && m_demand.armed)
  {
    //Failsafe set, or no longer set but Tx armed when exiting failsafe
    demandedFlightState = FlightState::WAITING_TO_DISARM;
  }
  else if (m_demand.armed)
  {
    DemandProcessor::FlightState demandedFlightMode;

    if constexpr(InternalConfig::MODEL_IS_FIXED_WING)
    {
      demandedFlightMode = getDemandedFlightModeFixedWing();
    }
    else
    {
      demandedFlightMode = getDemandedFlightModeMultiCopter();
    }

    //If throttle is high and last state not a normal flight mode then wait to disarm, otherwise allow demanded flight state
    demandedFlightState = (m_throttleHigh && (*lastFlightState > FlightState::PROP_HANG)) ? FlightState::WAITING_TO_DISARM : demandedFlightMode;
  }
  else if (wifiApDemanded())
  {
    demandedFlightState = FlightState::AP_WIFI;
  }
  else if (FlightState::AP_WIFI == demandedFlightState)
  {
    //Wifi no longer demanded so reset processor to force clean start and file read.
    ESP.restart();
  }
  else
  {
    if (FlightState::DISARMED != *flightState)
    {
      demandedFlightState = FlightState::DISARMED;
    }
  }

  if (*flightState != demandedFlightState)
  {
    *lastFlightState = *flightState;
    *flightState = demandedFlightState;
  }
}


/**
* @brief  Determines if the throttle is not low.  
* @return True when throttle is high.
*/
bool
DemandProcessor::throttleIsHigh() const
{
  return m_throttleHigh;
}


/**
* @brief  Determines if wifi configurator mode is being demanded 
* @return True when disamred and throttle is high.
*/
bool
DemandProcessor::wifiApDemanded()
{
  return ((!m_demand.armed) && RxBase::isSwitchHigh(radioCtrl->getChannel<RcChannelName::THROTTLE>(m_normalisedData)));
}


/**
* @brief    Indicates the RC demanded state of the arming switch.
* @return   True when Tx is armed.
*/
bool
DemandProcessor::isArmed() const
{
  return m_demand.armed;
}


/**
* @brief    Determines the RC demanded flight mode for fixed wing aircraft.  
* @return   FlightState   The demanded flight state.
*/
DemandProcessor::FlightState
DemandProcessor::getDemandedFlightModeFixedWing()
{
  if constexpr(Config::USE_PROP_HANG_MODE)
  {
    if (m_demand.propHang)
    {
      return FlightState::PROP_HANG;
    }
  }

  const RxBase::SwitchPosition modeSwitchPosition = RxBase::getSwitch3Position(radioCtrl->getChannel<Config::MODE_CHANNEL>(m_normalisedData));

  switch (modeSwitchPosition)
  {
  case RxBase::SwitchPosition::SW_HIGH:
  {
    if constexpr (Config::USE_ACRO_TRAINER)
    {
      return FlightState::ACRO_TRAINER;
    }
    else
    {
      return FlightState::SELF_LEVELLED;
    }
  }
  break;

  case RxBase::SwitchPosition::SW_MID:
    return FlightState::RATE;
    break;

  default:  //Intentional fall through
  case RxBase::SwitchPosition::SW_LOW:
    return FlightState::PASS_THROUGH;
    break;
  }
}


/**
* @brief    Determines the RC demanded flight mode for multicopter aircraft.  
* @return   FlightState   The demanded flight state.
*/
DemandProcessor::FlightState
DemandProcessor::getDemandedFlightModeMultiCopter()
{
  RxBase::SwitchPosition switchPosition = RxBase::getSwitch3Position(radioCtrl->getChannel<Config::MODE_CHANNEL>(m_normalisedData));

  switch (switchPosition)
  {
  case RxBase::SwitchPosition::SW_HIGH:
    return FlightState::SELF_LEVELLED;
    break;

  case RxBase::SwitchPosition::SW_MID:
    return FlightState::ACRO_TRAINER;
    break;

  default:  //Intentional fall through
  case RxBase::SwitchPosition::SW_LOW:
    return FlightState::RATE;
    break;
  }
}


/**
* @brief    Gets the heading hold demand.    
* @return   True when switch is high.
*/
bool
DemandProcessor::headingHoldActive() const
{
  return m_demand.headingHold;
}


/**
* @brief    Gets the prop hanging mode demand.    
* @return   True when switch is high.
*/
bool
DemandProcessor::propHangActive() const
{
  return m_demand.propHang;
}


/**
* @brief    Indicates the failsafe state.    
* @return   Returns true if Rx has entered failsafe
*/
bool
DemandProcessor::inFailsafeState()
{
  return m_normalisedData.failsafe;
}


/**
* @brief    Prints DemandProcessor data to console for debugging purposes.
*/
void
DemandProcessor::printData()
{
  if constexpr (InternalConfig::DEBUG_RC_DATA)
  {
    Serial.printf("pitch: %5d roll: %5d yaw: %5d throttle: %5d flaps: %5d %8s mode: %1d ", 
      m_demand.pitch, m_demand.roll, m_demand.yaw, m_demand.throttle, m_demand.flaps, 
      m_demand.armed ? "ARMED": "DISARMED", static_cast<uint8_t>(getDemandedFlightModeFixedWing()));
    if constexpr(Config::USE_HEADING_HOLD)
    {
      Serial.printf(" HeadingHold: %3s", m_demand.headingHold ? "On" : "Off");
    }
    if constexpr(Config::USE_PROP_HANG_MODE)
    {
      Serial.printf(" PropHang: %3s\n", m_demand.propHang ? "On" : "Off");
    } 
    else 
    {
    Serial.println();
    }
  }
}
