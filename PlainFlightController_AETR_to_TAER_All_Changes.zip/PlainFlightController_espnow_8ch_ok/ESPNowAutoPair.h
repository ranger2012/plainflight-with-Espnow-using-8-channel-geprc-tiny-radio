#ifndef ESPNOW_AUTOPAIR_H
#define ESPNOW_AUTOPAIR_H

#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <freertos/FreeRTOS.h>
#include <freertos/portmacro.h>

#if !defined(ESP_ARDUINO_VERSION_MAJOR) || ESP_ARDUINO_VERSION_MAJOR < 3
#error "ESPNowAutoPair requires Arduino-ESP32 core 3.x or newer."
#endif

#define ESPNOW_CHANNEL 1
#define ESPNOW_MAGIC 0xA5
#define ESPNOW_PAIR_REQUEST 0x01
#define ESPNOW_PAIR_RESPONSE 0x02
#define ESPNOW_DATA 0x10
#define ESPNOW_LINK_ACK 0x11
#define ESPNOW_MAX_DATA 200

class ESPNowAutoPair {
public:
  ESPNowAutoPair();
  bool beginTX();
  bool beginRX();
  void update();
  bool paired();
  bool send(const uint8_t *data, size_t length);
  bool receive(uint8_t *data, size_t maxLength, size_t &length);
  bool failsafe(uint32_t timeoutMs = 300);
  uint32_t lastReceive();
  void forget();

private:
  bool _tx;
  volatile bool _paired;
  uint8_t _peer[6];
  uint8_t _rxBuffer[ESPNOW_MAX_DATA];
  volatile size_t _rxLength;
  volatile bool _newPacket;
  volatile uint32_t _lastReceive;
  uint32_t _lastPairRequest;
  uint8_t _ackCounter;
  portMUX_TYPE _mux = portMUX_INITIALIZER_UNLOCKED;
  static ESPNowAutoPair *_instance;

  bool addPeer(const uint8_t *mac);
  void pairRequest();
  void onReceive(const esp_now_recv_info_t *info, const uint8_t *data, int len);
  static void receiveCallback(const esp_now_recv_info_t *info, const uint8_t *data, int len);
};

#endif
